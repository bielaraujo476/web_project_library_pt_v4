# Projeto 2: Biblioteca Triple Peaks

A página da biblioteca Triple Peaks é o segundo projeto no programa de desenvolvimento web na TripleTen. Ela foi criada usando HTML e CSS, com base no roteiro.

## Recursos do projeto

- HTML5 semântico
- Flexbox
